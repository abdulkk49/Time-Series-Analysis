#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <math.h>

typedef unsigned long long int llu_size;

struct entry{
	llu_size  Card_Number;
    char Bank_Code[6];
    char Expiry_Date[8];
    char First_Name[15];
    char Last_Name[15];
};


void read_accounts(FILE *f);
