#include "bank.h"

void read_accounts(FILE *f){   
    llu_size temp_size = 5;
    llu_size i = 0;
    struct entry e;
    struct entry *bank_accounts = (struct entry *) malloc (sizeof(struct entry) * temp_size);
    while(!feof(f)){
        if(i == temp_size){
            printf("inside if\n");
            temp_size *= 2;
            bank_accounts = (struct entry *) realloc(bank_accounts, sizeof(struct entry)*temp_size);
        }     
        fscanf(f,"\"%llu,%[^,],%[^,],%[^,],%[^\"]\"\n",&(e.Card_Number),e.Bank_Code, e.Expiry_Date, e.First_Name, e.Last_Name);
        bank_accounts[i++] = e;
        printf("Card number: %llu, Bank Code: %s,Expiry date: %s,Name: %s %s lol\n", bank_accounts[i].Card_Number, bank_accounts[i].Bank_Code, bank_accounts[i].Expiry_Date, bank_accounts[i].First_Name, bank_accounts[i].Last_Name);
    }
    fclose(f);
      
};

void main(){
    FILE *f;
    f = fopen("10", "r");
    read_accounts(f);
}